#coding: UTF8
"""
Encode streams

Classes:
    OutStreamEncoder
        Wraps a stream with an encoder.
        Example:
            sys.out = OutStreamEncoder(sys.out, "utf-8")

MIT license
"""

__author__ = "Ryan Ginstrom"
__version__ = "0.1"

import sys

class OutStreamEncoder(object):
    """Wraps a stream with an encoder
    
    USAGE
    >>> from cStringIO import StringIO as si
    >>> out = si()
    >>> nihongo = unicode("日本語", "utf-8")
    >>> print >> out, nihongo
    
    Traceback (most recent call last):
      File "<pyshell#40>", line 1, in <module>
        print >> out, nihongo
    UnicodeEncodeError: 'ascii' codec can't encode characters in position 0-2:
    ordinal not in range(128)
    >>> out = OutStreamEncoder(out, "utf-8")
    >>> print >> out, nihongo
    >>> val = out.getvalue()
    >>> print val.decode("utf-8")
    日本語
    """

    def __init__(self, outstream, encoding=None):
        self.out = outstream
        if not encoding:
            self.encoding = sys.getfilesystemencoding()
        else:
            self.encoding = encoding

    def write(self, obj):
        """Wraps the stream's output stream, encoding unicode
        strings with the specified encoding"""

        if isinstance(obj, unicode):
            self.out.write(obj.encode(self.encoding))
        else:
            self.out.write(obj)

    def __getattr__(self, attr):
        """Delegate everything but write to the stream"""

        return getattr(self.out, attr)
